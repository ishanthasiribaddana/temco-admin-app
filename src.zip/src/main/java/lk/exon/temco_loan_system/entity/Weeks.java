/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lk.exon.temco_loan_system.entity;

import jakarta.persistence.Basic;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQueries;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import java.io.Serializable;
import java.util.Collection;

/**
 *
 * @author USER
 */
@Entity
@Table(name = "weeks")
@NamedQueries({
    @NamedQuery(name = "Weeks.findAll", query = "SELECT w FROM Weeks w"),
    @NamedQuery(name = "Weeks.findById", query = "SELECT w FROM Weeks w WHERE w.id = :id"),
    @NamedQuery(name = "Weeks.findByName", query = "SELECT w FROM Weeks w WHERE w.name = :name")})
public class Weeks implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Column(name = "name")
    private String name;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "weeksId")
    private Collection<WeeksScheduler> weeksSchedulerCollection;

    public Weeks() {
    }

    public Weeks(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Collection<WeeksScheduler> getWeeksSchedulerCollection() {
        return weeksSchedulerCollection;
    }

    public void setWeeksSchedulerCollection(Collection<WeeksScheduler> weeksSchedulerCollection) {
        this.weeksSchedulerCollection = weeksSchedulerCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Weeks)) {
            return false;
        }
        Weeks other = (Weeks) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "lk.exon.temco_loan_system.entity.Weeks[ id=" + id + " ]";
    }
    
}
