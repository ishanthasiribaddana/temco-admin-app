/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lk.exon.temco_loan_system.common;

/**
 *
 * @author Nilupul Nethmina
 */
public class ComPath {

    public static final String LOGIN_URL = "https://api.javainstitute.edu.lk/TemcoStudntLogin";

    public static String basePath = "/root/temodocs/studentloansdocs/gurantordetails";
//    public static String depositsSlipsPath = "/root/temodocs/studentloansdocs/depositslips";
    public static String depositsSlipsPath = "F:/temco-bank-application-2024-07-08/imagesdepositslips";
    public static String promissoryNoteSubmittingUrl = "https://web.javainstitute.org/web-portal/PayOrder";
//    public static String basePath = "/root/testing/studentloansdocs/gurantordetails";

//    public static String viewURL = "http://5.189.137.149/mab_upload/";
//    public static String uploadURL = "/root/mab_images/mab_upload/";
}
